from django.contrib import admin
from .models import usr_class

admin.site.register(usr_class)


from tarfile import REGULAR_TYPES
from django.contrib import admin
from django.urls import path
from django.urls import URLPattern
urlpatterns = [
    
]